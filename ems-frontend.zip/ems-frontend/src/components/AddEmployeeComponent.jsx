import React from "react";
import { useState,useEffect } from "react";
import { useNavigate,useParams } from "react-router-dom";
import { createEmployee,getEmployee,updateEmployee } from "../services/EmployeeSevice";
const AddEmployeeComponent = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState({
    firstName: "",
    lastName: "",
    email: "",
  });
  const {id}=useParams();
  const navigator = useNavigate();

  useEffect(() => {
    
      // Fetch employee data and set it to state
         if(id){
          getEmployee(id).then((response) => {
            setFirstName(response.data.firstName);
            setLastName(response.data.lastName);
            setEmail(response.data.email);
          }).catch((error) => {
            console.error("Error fetching employee data:", error);
          });
        }
  }, [id])

  const handleFirstName = (event) => setFirstName(event.target.value);

  function handleLastName(event) {
    setLastName(event.target.value);
  }
  function handleEmail(event) {
    setEmail(event.target.value);
  }
  function saveorupdateEmployee(event) {
    event.preventDefault();
    if (validateForm()) {
      const employee = { firstName, lastName, email };
      console.log(employee);
      if(id){
        ``
/* Update employee logic here */
        updateEmployee(id, employee).then((response) => {
          console.log(response.data);
          navigator("/employees");
        
        }).catch((error) => {
          console.error("Error updating employee:", error);
        })
      }else{
           createEmployee(employee).then((response) => {
        console.log(response.data);
        navigator("/employees")

      }).catch((error) => {
        console.error("Error creating employee:", error);
      })

      }
    }

      
      
   
    }
  
  function validateForm() {
    let Valid = true;
    const errorsCopy = { ...errors };
    if (firstName.trim() === "") {
      errorsCopy.firstName = "First name is required";
      Valid = false;
    } else {
      errorsCopy.firstName = "";
    }
    if (lastName.trim() === "") {
      errorsCopy.lastName = "Last name is required";
      Valid = false;
    } else {
      errorsCopy.lastName = "";
    }
    if (email.trim() === "") {
      errorsCopy.email = "Email is required";
      Valid = false;
    } else {
      errorsCopy.email = "";
    }

    setErrors(errorsCopy);
    return Valid;
  }
  function pageTitle() {
    if (id) {
      return <h1 className="text-center">Update Employee</h1>;
    } else {
      return <h1 className="text-center">Add Employee</h1>
    }
  }
  return (
    <div className="container pd-y-5">
      <div className="row">
        <div className="card col-md-6 offset-md-3 offset-md-3">
          {pageTitle()}
          <form onSubmit={saveorupdateEmployee}>
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">
                Email address
              </label>
              <input
                type="email"
                value={email}
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                id="exampleInputEmail1"
                aria-describedby="emailHelp"
                placeholder="enter email address"
                onChange={handleEmail}
              ></input>
              {errors.email && 
                <div className="invalid-feedback">{errors.email}</div>
              }

              <div id="emailHelp" class="form-text">
                We'll never share your email with anyone else.
              </div>
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">
                firstName
              </label>
              <input
                type="text"
                value={firstName}
                className={`form-control ${
                  errors.firstName ? "is-invalid" : ""
                }`}
                id="exampleInputPassword1"
                placeholder="enter Firstname"
                onChange={handleFirstName}
              ></input>
              {errors.firstName && 
                <div className="invalid-feedback">{errors.firstName}</div>
              }
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">
                lastName
              </label>
              <input
                type="text"
                value={lastName}
                className={`form-control ${errors.lastName ? "is-invalid" : ""}`}
                id="exampleInputPassword1"
                placeholder="enter Lastname"
                onChange={handleLastName}
              ></input>
              {errors.lastName && 
                <div className="invalid-feedback">{errors.lastName}</div>
              }
            </div>

            <button type="submit" class="btn btn-success">
              SaveEmployee
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
    

export default AddEmployeeComponent;
