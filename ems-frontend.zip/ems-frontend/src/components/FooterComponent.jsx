import React from 'react'

const FooterComponent = () => {
  return (
 <div className="page-wrapper" >
  

  
    <footer className='footer'>
      <p>&copy; {new Date().getFullYear()} My Company. All rights reserved.</p>
    </footer>


 </div>

    
  )
}

export default FooterComponent
